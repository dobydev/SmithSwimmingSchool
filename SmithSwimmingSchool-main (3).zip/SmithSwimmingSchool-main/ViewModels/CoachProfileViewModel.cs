﻿using System.ComponentModel.DataAnnotations;
namespace SmithSwimmingSchool.ViewModels

//Added 06OCT25 Karima, User Story 5
{
    public class CoachProfileViewModel
    {
        [Required, Display(Name = "Coach Name")]
        public string CoachName { get; set; } = string.Empty;

        [Phone, Display(Name = "Phone Number")]
        public string? PhoneNumber { get; set; }

        [DataType(DataType.MultilineText)]
        public string? Bio { get; set; }

        public string? Certifications { get; set; }

        // Existing photo preview
        public string? ExistingPhotoPath { get; set; }

        // New upload 
        [Display(Name = "Upload Photo (JPG/PNG)")]
        public IFormFile? Photo { get; set; }
    }
}