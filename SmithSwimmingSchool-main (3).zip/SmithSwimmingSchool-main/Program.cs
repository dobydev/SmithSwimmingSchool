/* Gabriel Doby, Gabe Armstrong, Baden Glass, Destini Liphart
   Dylan Medvik, Pavel Karima, Prashum  K C
   Group 1: Team Project
   CISS 411: Software Architecture with ASP.NET
   9/29/2025  */
// Modified 07OCT25 Karima, User Story 6

using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SmithSwimmingSchool.Models;

var builder = WebApplication.CreateBuilder(args);

// Pull the connection string from appsettings.json
var connection = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connection));

// Identity configuration
builder.Services.AddIdentity<ApplicationUser, IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

// Add services to the container
builder.Services.AddControllersWithViews();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// Configure HTTP request
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.UseSession();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

// Apply migration
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.Migrate();
}

app.Run();


