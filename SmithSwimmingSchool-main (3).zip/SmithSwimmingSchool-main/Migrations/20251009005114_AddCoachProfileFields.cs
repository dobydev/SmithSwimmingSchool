﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmithSwimmingSchool.Migrations
{
    /// <inheritdoc />
    public partial class AddCoachProfileFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ApplicationUserId",
                table: "Coaches",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Bio",
                table: "Coaches",
                type: "nvarchar(2000)",
                maxLength: 2000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Certifications",
                table: "Coaches",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PhotoPath",
                table: "Coaches",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Coaches_ApplicationUserId",
                table: "Coaches",
                column: "ApplicationUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Coaches_AspNetUsers_ApplicationUserId",
                table: "Coaches",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Coaches_AspNetUsers_ApplicationUserId",
                table: "Coaches");

            migrationBuilder.DropIndex(
                name: "IX_Coaches_ApplicationUserId",
                table: "Coaches");

            migrationBuilder.DropColumn(
                name: "ApplicationUserId",
                table: "Coaches");

            migrationBuilder.DropColumn(
                name: "Bio",
                table: "Coaches");

            migrationBuilder.DropColumn(
                name: "Certifications",
                table: "Coaches");

            migrationBuilder.DropColumn(
                name: "PhotoPath",
                table: "Coaches");
        }
    }
}
