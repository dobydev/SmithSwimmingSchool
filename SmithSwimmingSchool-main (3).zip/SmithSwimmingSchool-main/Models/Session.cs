﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
//Modified 07OCT25 Karima / User Story 6

namespace SmithSwimmingSchool.Models
{
    public class Session
    {
        public int SessionId { get; set; }

        [Required]
        public int LessonId { get; set; }
        [ForeignKey(nameof(LessonId))]
        public virtual Lesson? Lesson { get; set; }

        [Required]
        public int CoachId { get; set; }
        [ForeignKey(nameof(CoachId))]
        public virtual Coach? Coach { get; set; }

        [Required, Display(Name = "Start Time")]
        public DateTime StartTime { get; set; }

        [Required, Display(Name = "End Time")]
        public DateTime EndTime { get; set; }

        [Range(1, 100)]
        public int Capacity { get; set; } = 10;

        // linked swimmers
        public virtual ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
    }
}