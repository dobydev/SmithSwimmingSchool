﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
//Modified 07OCT25 Karima / User Story 6

namespace SmithSwimmingSchool.Models
{
    public class Lesson
    {
        public int LessonId { get; set; }

        [Required]
        [Display(Name = "Skill Level")]
        public string? SkillLevel { get; set; }

        [DataType(DataType.Currency)]
        public double Tuition { get; set; }

        // Foreign keys (optional links at the lesson level)
        [Display(Name = "Coach")]
        public int? CoachId { get; set; }

        [Display(Name = "Swimmer")]
        public int? SwimmerId { get; set; }

        // Navigation properties
        public virtual Coach? Coach { get; set; }
        public virtual Swimmer? Swimmer { get; set; }

        // Collections
        public virtual ICollection<Session> Sessions { get; set; } = new List<Session>();
        public virtual ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
    }
}
