﻿using Microsoft.AspNetCore.Identity;

namespace SmithSwimmingSchool.Models
{
    public class ApplicationUser: IdentityUser
    {

    }
}
