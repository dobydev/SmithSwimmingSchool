﻿using System.ComponentModel.DataAnnotations.Schema;

namespace SmithSwimmingSchool.Models
//Modified 07OCT25 Karima / User Story 6
{
    public class Enrollment
    {
        public int EnrollmentId { get; set; }
        public int SessionId { get; set; }
        [ForeignKey(nameof(SessionId))]
        public virtual Session? Session { get; set; }
        public int SwimmerId { get; set; }
        [ForeignKey(nameof(SwimmerId))]
        public virtual Swimmer? Swimmer { get; set; }


    }
}