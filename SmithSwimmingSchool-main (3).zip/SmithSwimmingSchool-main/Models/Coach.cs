﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmithSwimmingSchool.Models
{
    public class Coach
    {
        public int CoachId { get; set; }

        [Display(Name = "Coach Name")]
        public required string CoachName { get; set; }

        [Phone]
        [Display(Name = "Phone Number")]
        public string? PhoneNumber { get; set; }

        // User Story 5, Modified 05OCT25 Karima
        [Display(Name = "Bio")]
        [DataType(DataType.MultilineText)]
        [MaxLength(2000)]
        public string? Bio { get; set; }

        [Display(Name = "Certifications (comma-separated)")]
        [MaxLength(1000)]
        public string? Certifications { get; set; }

        // Relative path wroot
        [Display(Name = "Photo")]
        public string? PhotoPath { get; set; }

        // Coach login profile to ID match
        [Required]
        public string ApplicationUserId { get; set; } = default!;

        [ForeignKey(nameof(ApplicationUserId))]
        public ApplicationUser? User { get; set; }

        // Navigation properties
        public ICollection<Session> Sessions { get; set; } = new List<Session>();

    }
}
