﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmithSwimmingSchool.Models;
using SmithSwimmingSchool.ViewModels;
//Added 06OCT2025 Karima, User Story 5
namespace SmithSwimmingSchool.Controllers
{
    [Authorize] // User logged in verification
    public class CoachController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _env;

        public CoachController(ApplicationDbContext db, UserManager<ApplicationUser> um, IWebHostEnvironment env)
        {
            _db = db;
            _userManager = um;
            _env = env;
        }

        // Landing page
        public IActionResult Index() => View();

        // GET Coach profile
        // Coach CRUD personal profile
        [HttpGet]
        public async Task<IActionResult> Profile()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is null) return Challenge();

            var coach = await _db.Coaches
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.ApplicationUserId == user.Id);

            if (coach == null)
            {
                // Create new profile
                var vmNew = new CoachProfileViewModel
                {
                    CoachName = user.Email ?? "Coach",
                };
                return View(vmNew);
            }

            // Edit existing profile
            var vm = new CoachProfileViewModel
            {
                CoachName = coach.CoachName,
                PhoneNumber = coach.PhoneNumber,
                Bio = coach.Bio,
                Certifications = coach.Certifications,
                ExistingPhotoPath = coach.PhotoPath
            };
            return View(vm);
        }

        // POST Coach profile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(CoachProfileViewModel vm)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is null) return Challenge();

            if (!ModelState.IsValid)
                return View(vm);

            // Create upload folder if one doesnt exist
            var relFolder = "images/coaches";
            var absFolder = Path.Combine(_env.WebRootPath, relFolder);
            if (!Directory.Exists(absFolder))
                Directory.CreateDirectory(absFolder);

            string? newPhotoPath = null;
            if (vm.Photo is { Length: > 0 })
            {
                var ext = Path.GetExtension(vm.Photo.FileName).ToLowerInvariant();
                var allowed = new[] { ".jpg", ".jpeg", ".png" };
                if (!allowed.Contains(ext))
                {
                    ModelState.AddModelError(nameof(vm.Photo), "Only JPG or PNG files are allowed.");
                    return View(vm);
                }

                // Verify unique file name
                var fileName = $"{Guid.NewGuid()}{ext}";
                var absPath = Path.Combine(absFolder, fileName);
                using (var fs = new FileStream(absPath, FileMode.Create))
                {
                    await vm.Photo.CopyToAsync(fs);
                }
                newPhotoPath = "/" + Path.Combine(relFolder, fileName).Replace("\\", "/");
            }

            var coach = await _db.Coaches.FirstOrDefaultAsync(c => c.ApplicationUserId == user.Id);

            if (coach == null)
            {
                coach = new Coach
                {
                    ApplicationUserId = user.Id,
                    CoachName = vm.CoachName,
                    PhoneNumber = vm.PhoneNumber,
                    Bio = vm.Bio,
                    Certifications = vm.Certifications,
                    PhotoPath = newPhotoPath
                };
                _db.Coaches.Add(coach);
            }
            else
            {
                coach.CoachName = vm.CoachName;
                coach.PhoneNumber = vm.PhoneNumber;
                coach.Bio = vm.Bio;
                coach.Certifications = vm.Certifications;

                if (newPhotoPath != null)
                {
                    // Delete old profile if existing
                    if (!string.IsNullOrWhiteSpace(coach.PhotoPath))
                    {
                        var oldAbs = Path.Combine(_env.WebRootPath, coach.PhotoPath.TrimStart('/').Replace("/", Path.DirectorySeparatorChar.ToString()));
                        if (System.IO.File.Exists(oldAbs))
                            System.IO.File.Delete(oldAbs);
                    }
                    coach.PhotoPath = newPhotoPath;
                }

                _db.Coaches.Update(coach);
            }

            await _db.SaveChangesAsync();
            TempData["ProfileSaved"] = "Your profile was saved.";
            return RedirectToAction(nameof(Profile));
        }

        // Public views

        [AllowAnonymous]
        public async Task<IActionResult> Details(int id)
        {
            var coach = await _db.Coaches.AsNoTracking().FirstOrDefaultAsync(c => c.CoachId == id);
            if (coach == null) return NotFound();
            return View(coach);
        }

        [AllowAnonymous]
        public async Task<IActionResult> All()
        {
            var coaches = await _db.Coaches.AsNoTracking()
                .OrderBy(c => c.CoachName)
                .ToListAsync();
            return View(coaches);
        }
    }
}
